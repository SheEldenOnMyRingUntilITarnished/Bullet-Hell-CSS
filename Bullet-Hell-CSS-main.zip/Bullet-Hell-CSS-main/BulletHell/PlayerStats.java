
/**
 * This class holds all of the values of the player stats.
 *
 * @author Zachary
 * @version 0.1
 */
public class PlayerStats
{
    int playerDrag = 1;
    
    int playerHealth = 3;
    
    final int playerSize = 8;
    int playerX = 100;
    int playerY = 100;
    int playerXHOLD = 0;
    int playerYHOLD = 0;
    final int PLAYERSPEED = 2;
    final int PLAYERMAXSPEED = 10;
    final int PLAYERDASHDISTANCE = 33;
    final int PLAYERDASHCOOLDOWN = 3;
}
